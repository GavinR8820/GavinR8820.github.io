namespace SimpleGradeBook
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private Gradebook _gradebook = new Gradebook();
        public class Grade
        {
            public string Name { get; set; }
            public int Mark { get; set; }

            public Grade(string name, int mark)
            {
                Name = name;
                Mark = mark;
            }

            public override string ToString()
            {
                return $"{Name} - {Mark}";
            }


        }

        public class Gradebook
        {
            public List<Grade> Grades = new List<Grade>();

            private int studentCount = 0;
            private int failingGradeCount = 0;


            public int Records { get;}
            public int MinimumGrade { get;}
            public int MaximumGrade { get;}
            public int NumberOfFailingGrades { get;}
            public int Average { get;}
            public Gradebook()
            {

                Records = studentCount++;
                foreach (var grade in Grades)
                {
                    if(grade.Mark < MinimumGrade)
                    {
                        MinimumGrade = grade.Mark;
                    }
                }
                foreach (var grade in Grades)
                {
                    if(grade.Mark > MaximumGrade)
                    {
                        MaximumGrade = grade.Mark;
                    }
                }
                foreach(var grade in Grades)
                {
                    if(grade.Mark < 55)
                    {
                        failingGradeCount++;
                    }
                }
                NumberOfFailingGrades = failingGradeCount;

                foreach (var grade in Grades)
                {
                    var sum = 0;
                    sum += grade.Mark;

                    var average = sum / studentCount;
                }

            }
            public void AddToGradeBook(Grade grade)
            {
                MessageBox.Show("grade Added");
                Grades.Add(grade);
                studentCount++;
            }

        }


            

        private void btnRecordGrade_Click(object sender, EventArgs e)
        {
            string name = txtStudentName.Text;
            int grade = int.Parse(txtGrade.Text);

            string errors = "";

            if(grade < 0 || grade > 100)
            {
                errors += "invalid Grade";
                MessageBox.Show("The Numeric Grade must be at least between 0 and 100 ");
            }

            if (string.IsNullOrEmpty(txtStudentName.Text))
            {
                errors += "invalid Mark";
            }
            else
            {
                Grade newGrade = new Grade(name, grade);
                _gradebook.AddToGradeBook(newGrade);

                
            }

            lblErrorMessages.Text = errors;
            lblErrorMessages.Visible = true;
            lblErrorMessages.ForeColor = Color.Red;

            txtStudentName.Clear();
            txtGrade.Clear();

            statusLabelMain.Text = "The grade" + name + " {" + grade + "} was recorded";
            lblNumberOfRecordsValue.Text = _gradebook.Records.ToString();
            lblNumberOfFailuresValue.Text = _gradebook.NumberOfFailingGrades.ToString();
            lblMaximumValue.Text = _gradebook.MaximumGrade.ToString();
            lblMinimum.Text = _gradebook.MinimumGrade.ToString();
            lblAverageValue.Text = _gradebook.Average.ToString();
        }
        private void MainForm_Load(object sender, EventArgs e)
        {
            statusLabelMain.Text = "No grades recorded yet, please enter your grades";
            lblErrorMessages.Visible = false;
        }
    }
}