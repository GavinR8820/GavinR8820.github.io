﻿namespace SimpleGradeBook
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStudentName = new System.Windows.Forms.Label();
            this.txtStudentName = new System.Windows.Forms.TextBox();
            this.lblGrade = new System.Windows.Forms.Label();
            this.txtGrade = new System.Windows.Forms.TextBox();
            this.btnRecordGrade = new System.Windows.Forms.Button();
            this.statusStripMain = new System.Windows.Forms.StatusStrip();
            this.statusLabelMain = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBoxStatistics = new System.Windows.Forms.GroupBox();
            this.lblNumberOfFailuresValue = new System.Windows.Forms.Label();
            this.lblNumberOfFailures = new System.Windows.Forms.Label();
            this.lblAverageValue = new System.Windows.Forms.Label();
            this.lblAverage = new System.Windows.Forms.Label();
            this.lblMaximumValue = new System.Windows.Forms.Label();
            this.lblMaximum = new System.Windows.Forms.Label();
            this.lblMinimumValue = new System.Windows.Forms.Label();
            this.lblMinimum = new System.Windows.Forms.Label();
            this.lblNumberOfRecordsValue = new System.Windows.Forms.Label();
            this.lblNumberOfRecords = new System.Windows.Forms.Label();
            this.lblErrorMessages = new System.Windows.Forms.Label();
            this.statusStripMain.SuspendLayout();
            this.groupBoxStatistics.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblStudentName
            // 
            this.lblStudentName.AutoSize = true;
            this.lblStudentName.Location = new System.Drawing.Point(23, 23);
            this.lblStudentName.Name = "lblStudentName";
            this.lblStudentName.Size = new System.Drawing.Size(84, 15);
            this.lblStudentName.TabIndex = 0;
            this.lblStudentName.Text = "Student name:";
            // 
            // txtStudentName
            // 
            this.txtStudentName.Location = new System.Drawing.Point(113, 20);
            this.txtStudentName.Name = "txtStudentName";
            this.txtStudentName.Size = new System.Drawing.Size(260, 23);
            this.txtStudentName.TabIndex = 1;
            // 
            // lblGrade
            // 
            this.lblGrade.AutoSize = true;
            this.lblGrade.Location = new System.Drawing.Point(23, 59);
            this.lblGrade.Name = "lblGrade";
            this.lblGrade.Size = new System.Drawing.Size(41, 15);
            this.lblGrade.TabIndex = 2;
            this.lblGrade.Text = "Grade:";
            // 
            // txtGrade
            // 
            this.txtGrade.Location = new System.Drawing.Point(113, 56);
            this.txtGrade.Name = "txtGrade";
            this.txtGrade.Size = new System.Drawing.Size(260, 23);
            this.txtGrade.TabIndex = 3;
            // 
            // btnRecordGrade
            // 
            this.btnRecordGrade.Location = new System.Drawing.Point(23, 100);
            this.btnRecordGrade.Name = "btnRecordGrade";
            this.btnRecordGrade.Size = new System.Drawing.Size(104, 23);
            this.btnRecordGrade.TabIndex = 4;
            this.btnRecordGrade.Text = "Record grade";
            this.btnRecordGrade.UseVisualStyleBackColor = true;
            this.btnRecordGrade.Click += new System.EventHandler(this.btnRecordGrade_Click);
            // 
            // statusStripMain
            // 
            this.statusStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabelMain});
            this.statusStripMain.Location = new System.Drawing.Point(0, 191);
            this.statusStripMain.Name = "statusStripMain";
            this.statusStripMain.Size = new System.Drawing.Size(625, 22);
            this.statusStripMain.TabIndex = 5;
            this.statusStripMain.Text = "statusStripMain";
            // 
            // statusLabelMain
            // 
            this.statusLabelMain.Name = "statusLabelMain";
            this.statusLabelMain.Size = new System.Drawing.Size(269, 17);
            this.statusLabelMain.Text = "No grades recorded yet - please enter your grades";
            // 
            // groupBoxStatistics
            // 
            this.groupBoxStatistics.Controls.Add(this.lblNumberOfFailuresValue);
            this.groupBoxStatistics.Controls.Add(this.lblNumberOfFailures);
            this.groupBoxStatistics.Controls.Add(this.lblAverageValue);
            this.groupBoxStatistics.Controls.Add(this.lblAverage);
            this.groupBoxStatistics.Controls.Add(this.lblMaximumValue);
            this.groupBoxStatistics.Controls.Add(this.lblMaximum);
            this.groupBoxStatistics.Controls.Add(this.lblMinimumValue);
            this.groupBoxStatistics.Controls.Add(this.lblMinimum);
            this.groupBoxStatistics.Controls.Add(this.lblNumberOfRecordsValue);
            this.groupBoxStatistics.Controls.Add(this.lblNumberOfRecords);
            this.groupBoxStatistics.Location = new System.Drawing.Point(407, 20);
            this.groupBoxStatistics.Name = "groupBoxStatistics";
            this.groupBoxStatistics.Size = new System.Drawing.Size(183, 147);
            this.groupBoxStatistics.TabIndex = 6;
            this.groupBoxStatistics.TabStop = false;
            this.groupBoxStatistics.Text = "Statistics:";
            this.groupBoxStatistics.Visible = false;
            // 
            // lblNumberOfFailuresValue
            // 
            this.lblNumberOfFailuresValue.AutoSize = true;
            this.lblNumberOfFailuresValue.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNumberOfFailuresValue.Location = new System.Drawing.Point(103, 116);
            this.lblNumberOfFailuresValue.Name = "lblNumberOfFailuresValue";
            this.lblNumberOfFailuresValue.Size = new System.Drawing.Size(21, 15);
            this.lblNumberOfFailuresValue.TabIndex = 9;
            this.lblNumberOfFailuresValue.Text = "##";
            // 
            // lblNumberOfFailures
            // 
            this.lblNumberOfFailures.AutoSize = true;
            this.lblNumberOfFailures.Location = new System.Drawing.Point(16, 116);
            this.lblNumberOfFailures.Name = "lblNumberOfFailures";
            this.lblNumberOfFailures.Size = new System.Drawing.Size(72, 15);
            this.lblNumberOfFailures.TabIndex = 8;
            this.lblNumberOfFailures.Text = "# of failures:";
            // 
            // lblAverageValue
            // 
            this.lblAverageValue.AutoSize = true;
            this.lblAverageValue.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblAverageValue.Location = new System.Drawing.Point(103, 88);
            this.lblAverageValue.Name = "lblAverageValue";
            this.lblAverageValue.Size = new System.Drawing.Size(21, 15);
            this.lblAverageValue.TabIndex = 7;
            this.lblAverageValue.Text = "##";
            // 
            // lblAverage
            // 
            this.lblAverage.AutoSize = true;
            this.lblAverage.Location = new System.Drawing.Point(16, 90);
            this.lblAverage.Name = "lblAverage";
            this.lblAverage.Size = new System.Drawing.Size(53, 15);
            this.lblAverage.TabIndex = 6;
            this.lblAverage.Text = "Average:";
            // 
            // lblMaximumValue
            // 
            this.lblMaximumValue.AutoSize = true;
            this.lblMaximumValue.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblMaximumValue.Location = new System.Drawing.Point(103, 68);
            this.lblMaximumValue.Name = "lblMaximumValue";
            this.lblMaximumValue.Size = new System.Drawing.Size(21, 15);
            this.lblMaximumValue.TabIndex = 5;
            this.lblMaximumValue.Text = "##";
            // 
            // lblMaximum
            // 
            this.lblMaximum.AutoSize = true;
            this.lblMaximum.Location = new System.Drawing.Point(15, 68);
            this.lblMaximum.Name = "lblMaximum";
            this.lblMaximum.Size = new System.Drawing.Size(65, 15);
            this.lblMaximum.TabIndex = 4;
            this.lblMaximum.Text = "Maximum:";
            // 
            // lblMinimumValue
            // 
            this.lblMinimumValue.AutoSize = true;
            this.lblMinimumValue.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblMinimumValue.Location = new System.Drawing.Point(103, 44);
            this.lblMinimumValue.Name = "lblMinimumValue";
            this.lblMinimumValue.Size = new System.Drawing.Size(21, 15);
            this.lblMinimumValue.TabIndex = 3;
            this.lblMinimumValue.Text = "##";
            // 
            // lblMinimum
            // 
            this.lblMinimum.AutoSize = true;
            this.lblMinimum.Location = new System.Drawing.Point(15, 44);
            this.lblMinimum.Name = "lblMinimum";
            this.lblMinimum.Size = new System.Drawing.Size(63, 15);
            this.lblMinimum.TabIndex = 2;
            this.lblMinimum.Text = "Minimum:";
            // 
            // lblNumberOfRecordsValue
            // 
            this.lblNumberOfRecordsValue.AutoSize = true;
            this.lblNumberOfRecordsValue.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNumberOfRecordsValue.Location = new System.Drawing.Point(103, 22);
            this.lblNumberOfRecordsValue.Name = "lblNumberOfRecordsValue";
            this.lblNumberOfRecordsValue.Size = new System.Drawing.Size(21, 15);
            this.lblNumberOfRecordsValue.TabIndex = 1;
            this.lblNumberOfRecordsValue.Text = "##";
            // 
            // lblNumberOfRecords
            // 
            this.lblNumberOfRecords.AutoSize = true;
            this.lblNumberOfRecords.Location = new System.Drawing.Point(15, 22);
            this.lblNumberOfRecords.Name = "lblNumberOfRecords";
            this.lblNumberOfRecords.Size = new System.Drawing.Size(73, 15);
            this.lblNumberOfRecords.TabIndex = 0;
            this.lblNumberOfRecords.Text = "# of records:";
            // 
            // lblErrorMessages
            // 
            this.lblErrorMessages.AutoSize = true;
            this.lblErrorMessages.ForeColor = System.Drawing.Color.Red;
            this.lblErrorMessages.Location = new System.Drawing.Point(26, 136);
            this.lblErrorMessages.Name = "lblErrorMessages";
            this.lblErrorMessages.Size = new System.Drawing.Size(158, 15);
            this.lblErrorMessages.TabIndex = 7;
            this.lblErrorMessages.Text = "Placeholder for err messages";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(625, 213);
            this.Controls.Add(this.lblErrorMessages);
            this.Controls.Add(this.groupBoxStatistics);
            this.Controls.Add(this.statusStripMain);
            this.Controls.Add(this.btnRecordGrade);
            this.Controls.Add(this.txtGrade);
            this.Controls.Add(this.lblGrade);
            this.Controls.Add(this.txtStudentName);
            this.Controls.Add(this.lblStudentName);
            this.Name = "MainForm";
            this.Text = "Simple Grade Book";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.statusStripMain.ResumeLayout(false);
            this.statusStripMain.PerformLayout();
            this.groupBoxStatistics.ResumeLayout(false);
            this.groupBoxStatistics.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblStudentName;
        private TextBox txtStudentName;
        private Label lblGrade;
        private TextBox txtGrade;
        private Button btnRecordGrade;
        private StatusStrip statusStripMain;
        private ToolStripStatusLabel statusLabelMain;
        private GroupBox groupBoxStatistics;
        private Label lblNumberOfRecordsValue;
        private Label lblNumberOfRecords;
        private Label lblNumberOfFailuresValue;
        private Label lblNumberOfFailures;
        private Label lblAverageValue;
        private Label lblAverage;
        private Label lblMaximumValue;
        private Label lblMaximum;
        private Label lblMinimumValue;
        private Label lblMinimum;
        private Label lblErrorMessages;
    }
}