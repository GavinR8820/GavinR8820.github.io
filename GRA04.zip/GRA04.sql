# Gavin Rintoul
# PROG2220 Section 1
# Assigment 4 Task 1

# Question Number 1
# Selects order_id and counts them and then selects tax_amount and then gets the sum of all the data.
USE my_guitar_shop;
	SELECT
		COUNT(order_id), SUM(tax_amount)
	FROM
		orders;

# Assigment 4 Task 1       
# Question Number 2
# Selects category name then counts product id then gets the max of the list price and then joins categories and products to then be grouped by category name and then ordered by product id descending
USE my_guitar_shop;
	SELECT
		c.category_name, 
        COUNT(p.product_id) AS Count, 
        MAX(p.list_price) AS Max
	FROM
		categories AS c
			INNER JOIN
		products p ON c.category_id = p.category_id
	GROUP BY c.category_name
    ORDER BY p.product_id DESC;
    
# Assigment 4 Task 1
# Question Number 3
# Selects product name and use COALESCE then use SUM on the ttem price - discount amount then * the item id that has COUNT then joins products and orders through order items and product id then groups by product name with rollup
	USE my_guitar_shop;
    SELECT 
    COALESCE(p.product_name, 'Grand Total') AS 'Product Name',
    SUM(o.item_price - o.discount_amount) * COUNT(o.item_id) as 'Total Amount'
FROM
    products p
        LEFT JOIN
    order_items o ON p.product_id = o.product_id
GROUP BY p.product_name WITH ROLLUP;

# Assigment 4 Task 1
# Question Number 4
# Selects category name from categories than uses NOT EXISTS before the subquery where the subquery returns one row for each category that has never been assigned
	USE my_guitar_shop;
    SELECT
		category_name
	FROM
		categories c
	WHERE
		NOT EXISTS( SELECT
				*
			FROM
				products p
			WHERE
				p.category_id = c.category_id);

# Assigment 4 Task 2
# Question Number 1
# Selects the average score than the evaluatee id where its equal to id 105
	USE swexpert;
	SELECT 
		AVG(score), evaluatee_id
	FROM evaluation
	WHERE evaluatee_id = 105;
    
# Assigment 4 Task 2
# Question Number 2
# Selects and counts skill_id that are equal to 1
	USE swexpert;
    SELECT
		COUNT(skill_id)
	FROM consultant_skill
    WHERE skill_id = 1;

# Assigment 4 Task 2
# Question Number 3
# Selects first and last name from consultant than creates a sup query where it identifies which people worked with Mark Myers
	USE swexpert;
	SELECT 
		c_first|| ' ' ||c_last as fullname
	FROM 
		consultant 
	WHERE
		c_mi = (SELECT DISTINCT mgr_id 
        FROM project 
        WHERE mgr_id = (SELECT c_id 
        FROM consultant 
        WHERE c_last= 'MARK' and c_first= 'Myers'));
        
# Assigment 4 Task 2
# Question Number 4
# Selects p_id and project_name and than looks for projects with completed evaluations and projects managed by consultants with last name that starts with Z
	USE swexpert;
	SELECT p_id, project_name
		FROM project
		WHERE p_id IN (SELECT p_id
    FROM evaluation)
    UNION
    SELECT p_id, project_name
		FROM project
		WHERE p_id IN (SELECT p_id 
		FROM project_consultant 
		WHERE c_id IN (SELECT c_id
		FROM consultant 
		WHERE c_last LIKE 'Z%'));
        
# Assigment 4 Task 3
# Question Number 1              
#PART A
# alters the project consultants table and adds total days with a value of 0
	USE swexpert;
	INSERT INTO evaluation_audit (audit_id, audit_e_id, audit_user)
    VALUES (0, 90, 'GAVIN');

#PART B
#  updates project consultants column total days with the diffrence of roll off and roll on dates
	USE swexpert;
    UPDATE project_consultant
    SET total_days = roll_off_date - roll_on_date;
    
#PART C
#   SELECTS everything from project_consultant
	USE swexpert;
    SELECT *
    FROM project_consultant;

#PART D
# Alters project_consultant and Drops total dayts column
	ALTER TABLE project_consultant
    DROP COLUMN total_days;
    
# Assigment 4 Task 3
# Question Number 2
#PART A
# drops the evaluation audit table
	USE swexpert;
    DROP TABLE evaluation_audit;

#PART B
# Creates evaluation_audit table with the rows of audit_id, audit_e_id and audit_user
	USE swexpert;
	CREATE TABLE evaluation_audit(
    audit_id INT,
    audit_e_id INT,
    audit_score INT,
    audit_user INT);
    
#PART C
# Alters the consultant table and adds e id equal to 90 
	USE swexpert;
	ALTER TABLE evaluation_audit
    ADD audit_score VARCHAR (90) NOT NULL;
    
#PART D
# Selects everything from evaluation audit table
	USE swexpert;
    SELECT *
    FROM evaluation_audit;
    
# Assigment 4 Task 3
# Question Number 3
#PART A
# Creates a empty string that is NULL and then ALTERs the same table to stop NULLs
	USE swexpert;
    UPDATE evaluation_audit
    SET audit_user = 0
    WHERE audit_user IS NULL;
    ALTER TABLE evaluation_audit
    ALTER COLUMN audit_user NOT NULL;
    
#PART B
# alters table and adds another audit_date
    USE swexpert;
    ALTER TABLE evaluation_audit
    ADD audit_date DECIMAL (0) NOT NULL;

#PART C
# inserts audit id, audit e id, audit score, audit user, audit date with the values of 0, 0, 95, user and sysdate 
    USE swexpert;
	INSERT INTO evaluation_audit (audit_id, audit_e_id, audit_score, audit_user, audit_date)
    VALUES (0, 0, 95, USER(ME), SYSDATE());
    
#PART D
# selects eveything from evaluation audit
	USE swexpert; 
    SELECT *
    FROM evaluation_audit;
    
#PART E
# inserts score 99 to consultant 100
	USE swexpert;
    INSERT INTO evaluation_audit (audit_id, audit_e_id, audit_score)
    VALUES (100, 0, 99);
    
# Assigment 4 Task 3
# Question Number 4
# A negative test case by inserting a new row with an unkown skill_id to the project)skill table
	USE swexpert;
    INSERT INTO consultant_skill (skill_id)
    VALUES (NULL);
    
# Assigment 4 Task 3
# Question Number 5
# A negative test case that deletes a row from consultant table thats violates a foreign key
	USE swexpert;
    DELETE FROM consultant
    WHERE c_id = 100;
    

    
    
    
